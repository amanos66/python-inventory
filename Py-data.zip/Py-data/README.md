# Parts Database
- Python Pyqt and csv inventory database.
- It stores items by name, part name, stock number, price and quantity. We can update the database.