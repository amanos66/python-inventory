import sys
import csv
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem,
    QPushButton, QLineEdit, QLabel, QMessageBox, QHeaderView, QDialog, QFormLayout, QDialogButtonBox, QListWidget, QInputDialog
)
import datetime
import os
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import Qt
from PyQt5.QtPrintSupport import QPrinter, QPrintDialog
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr

CSV_FILE = 'parts_inventory.csv'
FIELDS = ['Name', 'Part Name', 'Stock Number', 'Price', 'Quantity', 'Picture']
SALES_FILE = 'sales.csv'
SALES_FIELDS = ['Date', 'Customer Name', 'Phone', 'Email', 'Item Name', 'Part Name', 'Stock Number', 'Price', 'Quantity']

class CartItem:
    def __init__(self, item_data, quantity):
        self.item_data = item_data
        self.quantity = quantity
        self.total = float(item_data['Price']) * quantity

class CartDialog(QDialog):
    def __init__(self, cart_items, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Shopping Cart')
        self.cart_items = cart_items
        layout = QVBoxLayout(self)
        
        # Cart items table
        self.cart_table = QTableWidget()
        self.cart_table.setColumnCount(5)
        self.cart_table.setHorizontalHeaderLabels(['Item Name', 'Part Name', 'Price', 'Quantity', 'Total'])
        self.cart_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        layout.addWidget(self.cart_table)
        
        # Total
        self.total_label = QLabel()
        layout.addWidget(self.total_label)
        
        # Buttons
        btn_layout = QHBoxLayout()
        self.remove_btn = QPushButton('Remove Selected')
        self.remove_btn.clicked.connect(self.remove_item)
        btn_layout.addWidget(self.remove_btn)
        
        self.clear_btn = QPushButton('Clear Cart')
        self.clear_btn.clicked.connect(self.clear_cart)
        btn_layout.addWidget(self.clear_btn)
        
        self.checkout_btn = QPushButton('Checkout')
        self.checkout_btn.clicked.connect(self.accept)
        btn_layout.addWidget(self.checkout_btn)
        
        self.cancel_btn = QPushButton('Cancel')
        self.cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(self.cancel_btn)
        
        layout.addLayout(btn_layout)
        self.update_display()
    
    def update_display(self):
        self.cart_table.setRowCount(len(self.cart_items))
        subtotal = 0
        for row, item in enumerate(self.cart_items):
            self.cart_table.setItem(row, 0, QTableWidgetItem(item.item_data['Name']))
            self.cart_table.setItem(row, 1, QTableWidgetItem(item.item_data['Part Name']))
            self.cart_table.setItem(row, 2, QTableWidgetItem(item.item_data['Price']))
            self.cart_table.setItem(row, 3, QTableWidgetItem(str(item.quantity)))
            self.cart_table.setItem(row, 4, QTableWidgetItem(f"${item.total:.2f}"))
            subtotal += item.total
        tax_rate = 0.07  # 7% sales tax
        tax_amount = subtotal * tax_rate
        total = subtotal + tax_amount
        self.total_label.setText(f"Subtotal: ${subtotal:.2f}\nSales Tax (7%): ${tax_amount:.2f}\nTotal: ${total:.2f}")
    
    def remove_item(self):
        current_row = self.cart_table.currentRow()
        if current_row >= 0:
            del self.cart_items[current_row]
            self.update_display()
    
    def clear_cart(self):
        self.cart_items.clear()
        self.update_display()

class SellDialog(QDialog):
    def __init__(self, item_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Sell Item')
        self.item_data = item_data
        layout = QFormLayout(self)
        self.customer_name = QLineEdit()
        self.phone = QLineEdit()
        self.email = QLineEdit()
        self.quantity = QLineEdit()
        self.quantity.setPlaceholderText(f"Max: {item_data['Quantity']}")
        layout.addRow('Customer Name:', self.customer_name)
        layout.addRow('Phone:', self.phone)
        layout.addRow('Email:', self.email)
        layout.addRow('Quantity:', self.quantity)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        # Connect signals for autofill
        self.phone.editingFinished.connect(self.autofill_by_phone)
        self.email.editingFinished.connect(self.autofill_by_email)
        self.locked = False

    def autofill_by_phone(self):
        phone = self.phone.text().strip()
        if not phone:
            self.customer_name.setReadOnly(False)
            self.email.setReadOnly(False)
            self.locked = False
            return
        found = False
        try:
            with open('sales.csv', 'r', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['Phone'] == phone:
                        self.customer_name.setText(row['Customer Name'])
                        self.email.setText(row['Email'])
                        self.customer_name.setReadOnly(True)
                        self.email.setReadOnly(True)
                        self.locked = True
                        found = True
                        break
        except FileNotFoundError:
            pass
        if not found:
            self.customer_name.clear()
            self.email.clear()
            self.customer_name.setReadOnly(False)
            self.email.setReadOnly(False)
            self.locked = False

    def autofill_by_email(self):
        email = self.email.text().strip()
        if not email:
            return
        try:
            with open('sales.csv', 'r', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['Email'] == email:
                        self.customer_name.setText(row['Customer Name'])
                        self.phone.setText(row['Phone'])
                        self.customer_name.setReadOnly(True)
                        self.phone.setReadOnly(True)
                        self.locked = True
                        return
        except FileNotFoundError:
            pass

    def get_data(self):
        return {
            'customer_name': self.customer_name.text().strip(),
            'phone': self.phone.text().strip(),
            'email': self.email.text().strip(),
            'quantity': self.quantity.text().strip()
        }

class CustomerSearchDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Search Customer')
        self.selected_customer = None
        layout = QVBoxLayout(self)
        form_layout = QFormLayout()
        self.phone = QLineEdit()
        self.email = QLineEdit()
        form_layout.addRow('Phone:', self.phone)
        form_layout.addRow('Email:', self.email)
        layout.addLayout(form_layout)
        self.list_widget = QListWidget()
        self.list_widget.hide()
        layout.addWidget(self.list_widget)
        self.buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.list_widget.itemClicked.connect(self.select_customer)
        self.found_customers = []

    def get_data(self):
        return {
            'phone': self.phone.text().strip(),
            'email': self.email.text().strip()
        }

    def show_customers(self, customers):
        self.found_customers = customers
        self.list_widget.clear()
        for c in customers:
            self.list_widget.addItem(f"{c['Customer Name']} | {c['Phone']} | {c['Email']}")
        self.list_widget.show()
        if customers:
            self.list_widget.setCurrentRow(0)

    def select_customer(self, item):
        idx = self.list_widget.currentRow()
        if 0 <= idx < len(self.found_customers):
            self.selected_customer = self.found_customers[idx]
            self.accept()

class ReceiptDialog(QDialog):
    def __init__(self, sale_info, parent=None):
        super().__init__(parent)
        self.setWindowTitle('Receipt')
        self.sale_info = sale_info
        layout = QVBoxLayout(self)
        self.text = self.generate_receipt_text()
        self.label = QLabel(self.text)
        self.label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(self.label)
        btn_layout = QHBoxLayout()
        self.print_btn = QPushButton('Print/Save PDF')
        self.print_btn.clicked.connect(self.print_receipt)
        btn_layout.addWidget(self.print_btn)
        self.email_btn = QPushButton('Email Receipt')
        self.email_btn.clicked.connect(self.email_receipt)
        btn_layout.addWidget(self.email_btn)
        layout.addLayout(btn_layout)

    def generate_receipt_text(self):
        s = self.sale_info
        subtotal = float(s['Price']) * int(s['Quantity'])
        tax_rate = 0.07  # 7% sales tax
        tax_amount = subtotal * tax_rate
        total = subtotal + tax_amount
        business_info = (
            "My Business Name\n"
            "123 Main Street\n"
            "City, State ZIP\n"
            "Phone: (123) 456-7890\n"
            "Email: info@mybusiness.com\n"
            "------------------------------\n"
        )
        thank_you = "\n------------------------------\nThank you for your business!"
        return (
            f"{business_info}RECEIPT\n"
            f"Date: {s['Date']}\n"
            f"Customer: {s['Customer Name']}\n"
            f"Phone: {s['Phone']}\n"
            f"Email: {s['Email']}\n"
            f"Item: {s['Item Name']} ({s['Part Name']})\n"
            f"Stock#: {s['Stock Number']}\n"
            f"Price: {s['Price']}\n"
            f"Quantity: {s['Quantity']}\n"
            f"Subtotal: ${subtotal:.2f}\n"
            f"Sales Tax (7%): ${tax_amount:.2f}\n"
            f"Total: ${total:.2f}" + thank_you
        )

    def print_receipt(self):
        printer = QPrinter()
        dialog = QPrintDialog(printer, self)
        if dialog.exec_() == QPrintDialog.Accepted:
            from PyQt5.QtGui import QTextDocument
            doc = QTextDocument(self.text)
            doc.print_(printer)

    def email_receipt(self):
        s = self.sale_info
        email = s['Email']
        if not email:
            email, ok = QInputDialog.getText(self, 'Customer Email', 'Enter customer email:')
            if not ok or not email.strip():
                QMessageBox.warning(self, 'Missing Email', 'No email address provided.')
                return
            email = email.strip()
        # Prompt for SMTP settings if not set
        smtp_settings = self.parent().smtp_settings if hasattr(self.parent(), 'smtp_settings') else None
        if not smtp_settings:
            smtp_settings = self.prompt_smtp_settings()
            if not smtp_settings:
                return
            self.parent().smtp_settings = smtp_settings
        try:
            msg = MIMEMultipart()
            msg['From'] = formataddr((smtp_settings['from_name'], smtp_settings['from_email']))
            msg['To'] = email
            msg['Subject'] = 'Your Receipt'
            msg.attach(MIMEText(self.text, 'plain'))
            server = smtplib.SMTP_SSL(smtp_settings['smtp_server'], smtp_settings['smtp_port'])
            server.login(smtp_settings['from_email'], smtp_settings['password'])
            server.sendmail(smtp_settings['from_email'], [email], msg.as_string())
            server.quit()
            QMessageBox.information(self, 'Email Sent', f'Receipt emailed to {email}!')
        except Exception as e:
            QMessageBox.warning(self, 'Email Error', f'Failed to send email: {e}')

    def prompt_smtp_settings(self):
        dlg = QDialog(self)
        dlg.setWindowTitle('SMTP Settings')
        layout = QFormLayout(dlg)
        smtp_server = QLineEdit('smtp.gmail.com')
        smtp_port = QLineEdit('465')
        from_email = QLineEdit()
        from_name = QLineEdit()
        password = QLineEdit()
        password.setEchoMode(QLineEdit.Password)
        layout.addRow('SMTP Server:', smtp_server)
        layout.addRow('SMTP Port:', smtp_port)
        layout.addRow('Your Email:', from_email)
        layout.addRow('Your Name:', from_name)
        layout.addRow('Password:', password)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        if dlg.exec_():
            return {
                'smtp_server': smtp_server.text().strip(),
                'smtp_port': int(smtp_port.text().strip()),
                'from_email': from_email.text().strip(),
                'from_name': from_name.text().strip(),
                'password': password.text()
            }
        return None

def remove_duplicate_customers_from_sales():
    import shutil
    if not os.path.exists(SALES_FILE):
        QMessageBox.information(None, 'No Sales', 'No sales records found.')
        return
    temp_file = SALES_FILE + '.tmp'
    seen = set()
    with open(SALES_FILE, 'r', newline='') as infile, open(temp_file, 'w', newline='') as outfile:
        reader = csv.DictReader(infile)
        writer = csv.DictWriter(outfile, fieldnames=reader.fieldnames)
        writer.writeheader()
        for row in reader:
            key = (row['Phone'], row['Email'])
            if key not in seen:
                writer.writerow(row)
                seen.add(key)
    shutil.move(temp_file, SALES_FILE)
    QMessageBox.information(None, 'Cleanup Complete', 'Duplicate customers removed from sales.csv.')

class PartsDatabase(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Parts Inventory Database')
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)

        # Search bar
        search_layout = QHBoxLayout()
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText('Search...')
        self.search_input.textChanged.connect(self.search_items)
        search_layout.addWidget(QLabel('Search:'))
        search_layout.addWidget(self.search_input)
        self.layout.addLayout(search_layout)

        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(len(FIELDS))
        self.table.setHorizontalHeaderLabels(FIELDS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setSelectionBehavior(self.table.SelectRows)
        self.layout.addWidget(self.table)
        self.table.cellClicked.connect(self.load_item_to_form)

        # Form for add/update
        form_layout = QHBoxLayout()
        self.inputs = []
        for field in FIELDS:
            if field == 'Picture':
                pic_layout = QVBoxLayout()
                self.pic_path = QLineEdit()
                self.pic_path.setPlaceholderText('Picture path')
                self.pic_upload_btn = QPushButton('Upload')
                self.pic_upload_btn.clicked.connect(self.upload_picture)
                pic_layout.addWidget(self.pic_path)
                pic_layout.addWidget(self.pic_upload_btn)
                form_layout.addLayout(pic_layout)
                self.inputs.append(self.pic_path)
            else:
                line_edit = QLineEdit()
                line_edit.setPlaceholderText(field)
                form_layout.addWidget(line_edit)
                self.inputs.append(line_edit)
        self.layout.addLayout(form_layout)

        # Image display (thumbnail preview)
        thumb_layout = QVBoxLayout()
        thumb_label = QLabel('Item Picture Preview:')
        thumb_layout.addWidget(thumb_label)
        self.image_label = QLabel()
        self.image_label.setFixedSize(100, 100)
        self.image_label.setStyleSheet('border: 1px solid #888; background: #eee;')
        self.image_label.setAlignment(Qt.AlignCenter)
        thumb_layout.addWidget(self.image_label)
        self.layout.addLayout(thumb_layout)

        # Buttons
        btn_layout = QHBoxLayout()
        self.add_btn = QPushButton('Add')
        self.add_btn.clicked.connect(self.add_item)
        btn_layout.addWidget(self.add_btn)

        self.update_btn = QPushButton('Update')
        self.update_btn.clicked.connect(self.update_item)
        btn_layout.addWidget(self.update_btn)

        self.delete_btn = QPushButton('Delete')
        self.delete_btn.clicked.connect(self.delete_item)
        btn_layout.addWidget(self.delete_btn)

        self.save_btn = QPushButton('Save')
        self.save_btn.clicked.connect(self.save_to_csv)
        btn_layout.addWidget(self.save_btn)

        self.load_btn = QPushButton('Load')
        self.load_btn.clicked.connect(self.load_from_csv)
        btn_layout.addWidget(self.load_btn)

        self.layout.addLayout(btn_layout)

        # Add Sell and Customer Search buttons
        extra_btn_layout = QHBoxLayout()
        self.sell_btn = QPushButton('Sell')
        self.sell_btn.clicked.connect(self.sell_item)
        extra_btn_layout.addWidget(self.sell_btn)
        self.customer_search_btn = QPushButton('Customer Search')
        self.customer_search_btn.clicked.connect(self.customer_search)
        extra_btn_layout.addWidget(self.customer_search_btn)
        self.layout.addLayout(extra_btn_layout)

        # Cart buttons
        cart_btn_layout = QHBoxLayout()
        self.add_to_cart_btn = QPushButton('Add to Cart')
        self.add_to_cart_btn.clicked.connect(self.add_to_cart)
        cart_btn_layout.addWidget(self.add_to_cart_btn)
        
        self.view_cart_btn = QPushButton('View Cart')
        self.view_cart_btn.clicked.connect(self.view_cart)
        cart_btn_layout.addWidget(self.view_cart_btn)
        
        self.layout.addLayout(cart_btn_layout)

        # Duplicate cleanup button
        cleanup_btn_layout = QHBoxLayout()
        self.cleanup_btn = QPushButton('Remove Duplicate Customers')
        self.cleanup_btn.clicked.connect(self.remove_duplicates)
        cleanup_btn_layout.addWidget(self.cleanup_btn)
        self.layout.addLayout(cleanup_btn_layout)

        self.selected_row = None
        self.selected_customer = None
        self.load_from_csv()
        self.cart_items = []

    def add_item(self):
        values = [i.text().strip() for i in self.inputs]
        # Only require fields except Picture
        if not all(values[:FIELDS.index('Picture')]):
            QMessageBox.warning(self, 'Input Error', 'All fields except Picture are required.')
            return
        self.table.insertRow(self.table.rowCount())
        for col, value in enumerate(values):
            self.table.setItem(self.table.rowCount()-1, col, QTableWidgetItem(value))
        for i in self.inputs:
            i.clear()
        self.image_label.clear()
        self.save_to_csv()

    def update_item(self):
        if self.selected_row is None:
            QMessageBox.warning(self, 'Selection Error', 'No item selected.')
            return
        values = [i.text().strip() for i in self.inputs]
        if not all(values[:FIELDS.index('Picture')]):
            QMessageBox.warning(self, 'Input Error', 'All fields except Picture are required.')
            return
        for col, value in enumerate(values):
            self.table.setItem(self.selected_row, col, QTableWidgetItem(value))
        for i in self.inputs:
            i.clear()
        self.image_label.clear()
        self.selected_row = None
        self.table.clearSelection()
        self.save_to_csv()

    def delete_item(self):
        if self.selected_row is None:
            QMessageBox.warning(self, 'Selection Error', 'No item selected.')
            return
        self.table.removeRow(self.selected_row)
        for i in self.inputs:
            i.clear()
        self.image_label.clear()
        self.selected_row = None
        self.table.clearSelection()
        self.save_to_csv()

    def load_item_to_form(self, row, _):
        self.selected_row = row
        for col in range(len(FIELDS)):
            cell = self.table.item(row, col)
            self.inputs[col].setText(cell.text() if cell else "")
        # Show image if available
        pic_col = FIELDS.index('Picture')
        pic_cell = self.table.item(row, pic_col)
        pic_path = pic_cell.text() if pic_cell else ""
        if pic_path and os.path.exists(pic_path):
            pixmap = QPixmap(pic_path)
            self.image_label.setPixmap(pixmap.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            self.image_label.clear()

    def save_to_csv(self):
        with open(CSV_FILE, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(FIELDS)
            for row in range(self.table.rowCount()):
                writer.writerow([
                    self.table.item(row, col).text() for col in range(self.table.columnCount())
                ])
        QMessageBox.information(self, 'Saved', 'Database saved to CSV.')

    def load_from_csv(self):
        self.table.setRowCount(0)
        try:
            with open(CSV_FILE, 'r', newline='') as f:
                reader = csv.reader(f)
                headers = next(reader, None)
                # Map CSV columns to FIELDS
                col_map = [headers.index(field) if field in headers else -1 for field in FIELDS]
                for row_data in reader:
                    row = self.table.rowCount()
                    self.table.insertRow(row)
                    for col, field in enumerate(FIELDS):
                        idx = col_map[col]
                        value = row_data[idx] if idx >= 0 and idx < len(row_data) else ""
                        self.table.setItem(row, col, QTableWidgetItem(value))
                    # Show image for first row loaded
                    if row == 0:
                        pic_col = FIELDS.index('Picture')
                        pic_idx = col_map[pic_col]
                        pic_path = row_data[pic_idx] if pic_idx >= 0 and pic_idx < len(row_data) else ""
                        if pic_path and os.path.exists(pic_path):
                            pixmap = QPixmap(pic_path)
                            self.image_label.setPixmap(pixmap.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))
                        else:
                            self.image_label.clear()
        except FileNotFoundError:
            pass

    def search_items(self):
        query = self.search_input.text().lower()
        for row in range(self.table.rowCount()):
            match = False
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item and query in item.text().lower():
                    match = True
                    break
            self.table.setRowHidden(row, not match)

    def sell_item(self):
        if self.selected_row is None:
            QMessageBox.warning(self, 'Selection Error', 'Select an item to sell.')
            return
        item_data = {}
        for col in range(len(FIELDS)):
            # Only require non-Picture fields
            cell = self.table.item(self.selected_row, col)
            if cell is None and FIELDS[col] != 'Picture':
                QMessageBox.warning(self, 'Data Error', f'Missing data in column: {FIELDS[col]}')
                return
            item_data[FIELDS[col]] = cell.text() if cell else ""
        # Pre-fill customer info if available
        dlg = SellDialog(item_data, self)
        if self.selected_customer:
            dlg.customer_name.setText(self.selected_customer['Customer Name'])
            dlg.phone.setText(self.selected_customer['Phone'])
            dlg.email.setText(self.selected_customer['Email'])
        if dlg.exec_():
            data = dlg.get_data()
            # Validate
            if not data['phone'] or not data['quantity']:
                QMessageBox.warning(self, 'Input Error', 'Phone number and quantity are required.')
                return
            # If phone exists in sales, always use the existing name/email
            try:
                with open(SALES_FILE, 'r', newline='') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        if row['Phone'] == data['phone']:
                            data['customer_name'] = row['Customer Name']
                            data['email'] = row['Email']
                            break
            except FileNotFoundError:
                pass
            try:
                qty = int(data['quantity'])
                stock_qty = int(item_data['Quantity'])
                if qty <= 0 or qty > stock_qty:
                    raise ValueError
            except ValueError:
                QMessageBox.warning(self, 'Input Error', 'Invalid quantity.')
                return
            # Update inventory
            self.table.setItem(self.selected_row, FIELDS.index('Quantity'), QTableWidgetItem(str(stock_qty - qty)))
            # Record sale
            sale_row = [
                datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                data['customer_name'],
                data['phone'],
                data['email'],
                item_data['Name'],
                item_data['Part Name'],
                item_data['Stock Number'],
                item_data['Price'],
                str(qty)
            ]
            try:
                with open(SALES_FILE, 'a', newline='') as f:
                    writer = csv.writer(f)
                    if f.tell() == 0:
                        writer.writerow(SALES_FIELDS)
                    writer.writerow(sale_row)
                # Automatically save inventory after sale
                self.save_to_csv()
                # Show receipt dialog
                sale_info = {
                    'Date': sale_row[0],
                    'Customer Name': sale_row[1],
                    'Phone': sale_row[2],
                    'Email': sale_row[3],
                    'Item Name': sale_row[4],
                    'Part Name': sale_row[5],
                    'Stock Number': sale_row[6],
                    'Price': sale_row[7],
                    'Quantity': sale_row[8],
                }
                dlg = ReceiptDialog(sale_info, self)
                dlg.exec_()
                QMessageBox.information(self, 'Sale Recorded', 'Sale recorded and inventory updated.')
                # Clear form and selection after sale
                for i in self.inputs:
                    i.clear()
                self.selected_row = None
                self.table.clearSelection()
                self.selected_customer = None
            except Exception as e:
                QMessageBox.warning(self, 'Error', f'Could not record sale: {e}')

    def customer_search(self):
        dlg = CustomerSearchDialog(self)
        if dlg.exec_():
            data = dlg.get_data()
            if not data['phone'] and not data['email']:
                QMessageBox.warning(self, 'Input Error', 'Enter phone or email to search.')
                return
            # Search sales.csv
            found = []
            unique_keys = set()
            try:
                with open(SALES_FILE, 'r', newline='') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        key = row['Phone'] if data['phone'] else row['Email']
                        match = False
                        if data['phone'] and row['Phone'] == data['phone']:
                            match = True
                        if data['email'] and row['Email'] == data['email']:
                            match = True
                        if match and key not in unique_keys:
                            found.append(row)
                            unique_keys.add(key)
            except FileNotFoundError:
                QMessageBox.information(self, 'No Sales', 'No sales records found.')
                return
            if not found:
                QMessageBox.information(self, 'Not Found', 'No customer found with that phone or email.')
                return
            # Let user select customer if multiple found
            dlg.show_customers(found)
            if dlg.exec_():
                self.selected_customer = dlg.selected_customer
                if self.selected_customer:
                    msg = f"Customer Name: {self.selected_customer['Customer Name']}\nPhone: {self.selected_customer['Phone']}\nEmail: {self.selected_customer['Email']}"
                    QMessageBox.information(self, 'Customer Selected', msg)
                else:
                    QMessageBox.information(self, 'No Selection', 'No customer selected.')
            else:
                self.selected_customer = None

    def upload_picture(self):
        from PyQt5.QtWidgets import QFileDialog
        if not os.path.exists('images'):
            os.makedirs('images')
        file_path, _ = QFileDialog.getOpenFileName(self, 'Select Image', '', 'Images (*.png *.jpg *.jpeg *.bmp)')
        if file_path:
            file_name = os.path.basename(file_path)
            dest_path = os.path.join('images', file_name)
            # Avoid overwriting
            i = 1
            base, ext = os.path.splitext(file_name)
            while os.path.exists(dest_path):
                dest_path = os.path.join('images', f'{base}_{i}{ext}')
                i += 1
            import shutil
            shutil.copy(file_path, dest_path)
            self.pic_path.setText(dest_path)
            # Show preview
            pixmap = QPixmap(dest_path)
            self.image_label.setPixmap(pixmap.scaled(self.image_label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def add_to_cart(self):
        if self.selected_row is None:
            QMessageBox.warning(self, 'Selection Error', 'Select an item to add to cart.')
            return
        
        # Get item data
        item_data = {}
        for col in range(len(FIELDS)):
            cell = self.table.item(self.selected_row, col)
            if cell is None and FIELDS[col] != 'Picture':
                QMessageBox.warning(self, 'Data Error', f'Missing data in column: {FIELDS[col]}')
                return
            item_data[FIELDS[col]] = cell.text() if cell else ""
        
        # Get quantity
        quantity, ok = QInputDialog.getInt(self, 'Add to Cart', 'Quantity:', 1, 1, int(item_data['Quantity']))
        if not ok:
            return
        
        # Check if item already in cart
        for cart_item in self.cart_items:
            if cart_item.item_data['Stock Number'] == item_data['Stock Number']:
                QMessageBox.information(self, 'Already in Cart', 'This item is already in your cart.')
                return
        
        # Add to cart
        self.cart_items.append(CartItem(item_data, quantity))
        QMessageBox.information(self, 'Added to Cart', f'Added {quantity} x {item_data["Name"]} to cart.')

    def view_cart(self):
        if not self.cart_items:
            QMessageBox.information(self, 'Empty Cart', 'Your cart is empty.')
            return
        
        dlg = CartDialog(self.cart_items, self)
        if dlg.exec_() == QDialog.Accepted:
            self.checkout_cart()
        self.cart_items = dlg.cart_items

    def checkout_cart(self):
        if not self.cart_items:
            return
        
        # Get customer info
        customer_dlg = QDialog(self)
        customer_dlg.setWindowTitle('Customer Information')
        layout = QFormLayout(customer_dlg)
        
        customer_name = QLineEdit()
        phone = QLineEdit()
        email = QLineEdit()
        
        layout.addRow('Customer Name:', customer_name)
        layout.addRow('Phone:', phone)
        layout.addRow('Email:', email)
        
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(customer_dlg.accept)
        btns.rejected.connect(customer_dlg.reject)
        
        if not customer_dlg.exec_():
            return
        
        # Validate customer info
        if not phone.text().strip():
            QMessageBox.warning(self, 'Input Error', 'Phone number is required.')
            return
        
        # Process all items in cart
        sale_date = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        customer_name_text = customer_name.text().strip()
        phone_text = phone.text().strip()
        email_text = email.text().strip()
        
        # Auto-fill customer info if phone exists
        try:
            with open(SALES_FILE, 'r', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if row['Phone'] == phone_text:
                        customer_name_text = row['Customer Name']
                        email_text = row['Email']
                        break
        except FileNotFoundError:
            pass
        
        # Record all sales
        try:
            with open(SALES_FILE, 'a', newline='') as f:
                writer = csv.writer(f)
                if f.tell() == 0:
                    writer.writerow(SALES_FIELDS)
                
                for cart_item in self.cart_items:
                    # Update inventory
                    for row in range(self.table.rowCount()):
                        if self.table.item(row, FIELDS.index('Stock Number')).text() == cart_item.item_data['Stock Number']:
                            current_qty = int(self.table.item(row, FIELDS.index('Quantity')).text())
                            new_qty = current_qty - cart_item.quantity
                            self.table.setItem(row, FIELDS.index('Quantity'), QTableWidgetItem(str(new_qty)))
                            break
                    
                    # Record sale
                    subtotal = float(cart_item.item_data['Price']) * cart_item.quantity
                    tax_rate = 0.07  # 7% sales tax
                    tax_amount = subtotal * tax_rate
                    total = subtotal + tax_amount
                    sale_row = [
                        sale_date,
                        customer_name_text,
                        phone_text,
                        email_text,
                        cart_item.item_data['Name'],
                        cart_item.item_data['Part Name'],
                        cart_item.item_data['Stock Number'],
                        cart_item.item_data['Price'],
                        str(cart_item.quantity)
                    ]
                    writer.writerow(sale_row)
            
            # Save inventory
            self.save_to_csv()
            
            # Show receipt
            self.show_cart_receipt(customer_name_text, phone_text, email_text, sale_date)
            
            # Clear cart
            self.cart_items.clear()
            
            QMessageBox.information(self, 'Sale Complete', 'All items have been sold successfully!')
            
        except Exception as e:
            QMessageBox.warning(self, 'Error', f'Could not complete sale: {e}')

    def show_cart_receipt(self, customer_name, phone, email, sale_date):
        subtotal = sum(item.total for item in self.cart_items)
        tax_rate = 0.07  # 7% sales tax
        tax_amount = subtotal * tax_rate
        total = subtotal + tax_amount
        
        receipt_text = (
            "My Business Name\n"
            "123 Main Street\n"
            "City, State ZIP\n"
            "Phone: (123) 456-7890\n"
            "Email: info@mybusiness.com\n"
            "------------------------------\n"
            "RECEIPT\n"
            f"Date: {sale_date}\n"
            f"Customer: {customer_name}\n"
            f"Phone: {phone}\n"
            f"Email: {email}\n"
            "------------------------------\n"
        )
        
        for item in self.cart_items:
            receipt_text += (
                f"Item: {item.item_data['Name']} ({item.item_data['Part Name']})\n"
                f"Stock#: {item.item_data['Stock Number']}\n"
                f"Price: {item.item_data['Price']}\n"
                f"Quantity: {item.quantity}\n"
                f"Subtotal: ${item.total:.2f}\n"
                "------------------------------\n"
            )
        
        receipt_text += f"Subtotal: ${subtotal:.2f}\n"
        receipt_text += f"Sales Tax (7%): ${tax_amount:.2f}\n"
        receipt_text += f"TOTAL: ${total:.2f}\n"
        receipt_text += "------------------------------\nThank you for your business!"
        
        # Show receipt dialog
        dlg = QDialog(self)
        dlg.setWindowTitle('Receipt')
        layout = QVBoxLayout(dlg)
        
        receipt_label = QLabel(receipt_text)
        receipt_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        layout.addWidget(receipt_label)
        
        btn_layout = QHBoxLayout()
        print_btn = QPushButton('Print/Save PDF')
        print_btn.clicked.connect(lambda: self.print_receipt(receipt_text))
        btn_layout.addWidget(print_btn)
        
        email_btn = QPushButton('Email Receipt')
        email_btn.clicked.connect(lambda: self.email_receipt(receipt_text, email))
        btn_layout.addWidget(email_btn)
        
        close_btn = QPushButton('Close')
        close_btn.clicked.connect(dlg.accept)
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        dlg.exec_()

    def print_receipt(self, text):
        printer = QPrinter()
        dialog = QPrintDialog(printer, self)
        if dialog.exec_() == QPrintDialog.Accepted:
            from PyQt5.QtGui import QTextDocument
            doc = QTextDocument(text)
            doc.print_(printer)

    def email_receipt(self, text, email):
        if not email:
            email, ok = QInputDialog.getText(self, 'Customer Email', 'Enter customer email:')
            if not ok or not email.strip():
                QMessageBox.warning(self, 'Missing Email', 'No email address provided.')
                return
            email = email.strip()
        
        # Use existing SMTP settings or prompt for new ones
        smtp_settings = getattr(self, 'smtp_settings', None)
        if not smtp_settings:
            smtp_settings = self.prompt_smtp_settings()
            if not smtp_settings:
                return
            self.smtp_settings = smtp_settings
        
        try:
            msg = MIMEMultipart()
            msg['From'] = formataddr((smtp_settings['from_name'], smtp_settings['from_email']))
            msg['To'] = email
            msg['Subject'] = 'Your Receipt'
            msg.attach(MIMEText(text, 'plain'))
            server = smtplib.SMTP_SSL(smtp_settings['smtp_server'], smtp_settings['smtp_port'])
            server.login(smtp_settings['from_email'], smtp_settings['password'])
            server.sendmail(smtp_settings['from_email'], [email], msg.as_string())
            server.quit()
            QMessageBox.information(self, 'Email Sent', 'Receipt emailed successfully!')
        except Exception as e:
            QMessageBox.warning(self, 'Email Error', f'Failed to send email: {e}')

    def prompt_smtp_settings(self):
        dlg = QDialog(self)
        dlg.setWindowTitle('SMTP Settings')
        layout = QFormLayout(dlg)
        smtp_server = QLineEdit('smtp.gmail.com')
        smtp_port = QLineEdit('465')
        from_email = QLineEdit()
        from_name = QLineEdit()
        password = QLineEdit()
        password.setEchoMode(QLineEdit.Password)
        layout.addRow('SMTP Server:', smtp_server)
        layout.addRow('SMTP Port:', smtp_port)
        layout.addRow('Your Email:', from_email)
        layout.addRow('Your Name:', from_name)
        layout.addRow('Password:', password)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(btns)
        btns.accepted.connect(dlg.accept)
        btns.rejected.connect(dlg.reject)
        if dlg.exec_():
            return {
                'smtp_server': smtp_server.text().strip(),
                'smtp_port': int(smtp_port.text().strip()),
                'from_email': from_email.text().strip(),
                'from_name': from_name.text().strip(),
                'password': password.text()
            }
        return None

    def remove_duplicates(self):
        remove_duplicate_customers_from_sales()

def main():
    app = QApplication(sys.argv)
    # Modern stylesheet
    app.setStyleSheet('''
        QWidget {
            font-family: "Segoe UI", "Arial", sans-serif;
            font-size: 13px;
        }
        QMainWindow, QWidget {
            background: #f7f7fa;
        }
        QTableWidget {
            background: #fff;
            border-radius: 8px;
            border: 1px solid #d0d0d0;
            padding: 4px;
        }
        QTableWidget::item {
            padding: 6px;
        }
        QLineEdit, QComboBox, QTextEdit {
            border: 1px solid #b0b0b0;
            border-radius: 6px;
            padding: 6px;
            background: #fff;
        }
        QPushButton {
            background: #4f8cff;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 7px 18px;
            font-weight: 500;
            margin: 2px;
        }
        QPushButton:hover {
            background: #2566d8;
        }
        QLabel {
            color: #222;
        }
        QHeaderView::section {
            background: #e9e9ef;
            border: none;
            border-radius: 6px;
            padding: 6px;
            font-weight: 600;
        }
        QListWidget {
            background: #fff;
            border-radius: 6px;
            border: 1px solid #d0d0d0;
        }
        QDialog {
            background: #f7f7fa;
            border-radius: 10px;
        }
    ''')
    window = PartsDatabase()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    main() 